# Cearáchat — protótipo web mobile

Uma primeira versão responsiva da interface de uma rede social inspirada em padrões comuns de redes de vídeos e fotos, com identidade própria.

## O que já funciona nesta versão
- Navegação entre Início, Vídeos, Pesquisa, Mensagens e Perfil.
- Publicações de texto/foto/vídeo, curtidas e comentários.
- Stories de demonstração e criação de stories.
- Pesquisa local nas publicações carregadas.
- Conversas de demonstração e envio de mensagens locais.
- Edição do perfil.
- Salvamento no armazenamento local do navegador; PWA/service worker para instalação quando servido por HTTPS.

## Importante: limite atual
Esta entrega é um **protótipo funcional local**, não uma rede social multiusuário publicada. Dados e mensagens ficam somente no navegador/aparelho em que foram criados. Não há contas reais, sincronização entre usuários, armazenamento remoto nem mensagens em tempo real. Para liberar isso para pessoas diferentes, configure backend, autenticação, banco, armazenamento de mídia e políticas de acesso.

## Como testar no iPhone
1. Baixe e extraia o ZIP.
2. Publique a pasta em um serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages ou Netlify). Para um projeto privado ou mais simples, use um serviço com upload de pasta/arquivos pelo navegador.
3. Abra o endereço HTTPS no Safari do iPhone.
4. Para adicionar à tela inicial: toque em **Compartilhar** no Safari → **Adicionar à Tela de Início**.

O arquivo `index.html` pode ser aberto para inspeção, mas recursos de PWA/Service Worker exigem um endereço servido por HTTPS ou localhost. O upload de fotos/vídeos usa armazenamento do navegador e é limitado; o tamanho recomendado por arquivo nesta demonstração é 12 MB.

## Próxima etapa para tornar uma rede social real
A arquitetura recomendada é Supabase (Auth + PostgreSQL + Storage + Realtime) ou um backend equivalente. Criar as tabelas `profiles`, `posts`, `stories`, `follows`, `likes`, `comments`, `conversations`, `conversation_members` e `messages`; ativar RLS em todas as tabelas; configurar políticas para que usuários só alterem seus próprios dados e só membros leiam/enviem mensagens de uma conversa. Mídia deve ir para buckets privados/públicos conforme o tipo, com limites e validação. Nunca colocar uma chave `service_role` no frontend. Uma chave pública/anon pode estar no frontend somente com RLS bem configurado.

## Estrutura
- `index.html`: telas e modais.
- `style.css`: visual responsivo.
- `app.js`: interações e dados locais.
- `manifest.webmanifest`: metadados de instalação.
- `sw.js`: cache básico da interface.
